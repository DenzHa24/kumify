# Kumify
A chrome extension that makes every thumbnail on youtube have kumiko!

I got inspired by chikenuwu and mrBeastify
this was just forked from chikenuwu's implementation
HUGE THANKS TO HIM

chikenuwu: https://github.com/IsaacSohn/Sechify 

Mrbeastify: https://github.com/MagicJinn/MrBeastify-Youtube

If anybody wants to help add images to kumify. (You’ll be credited of course) please send 1280x720 transparent Kumiko PNGs to the following email dyingisbad@gmail.com any help is appreciated!

Image/gif Contributors!
friendlybaron 
laconchadetumadreallboys
